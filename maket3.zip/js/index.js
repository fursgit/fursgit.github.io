$(document).ready(function(){
  $('#nav-menu').click(function(){
      $('ul.menu').addClass('nav-open').slideToggle('300');
  });
});